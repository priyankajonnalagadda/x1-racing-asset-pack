# X1 Racing Asset Pack

A real-time game-ready racing asset project created for portfolio and internship applications.

## Planned Assets
- Futuristic Racing Checkpoint Gate
- Floating Buoys
- Water Barriers
- Racing Ramp
- Stylized Island Prop

## Workflow
- Blender (Modeling)
- Eevee (Real-time Rendering)
- Substance Painter (Texturing)
- Unity-ready exports

## Folder Structure
- Blender_Files → .blend project files
- Exports → FBX/OBJ/GLB exports
- Textures → PBR textures
- Renders → beauty renders and wireframes
- References → concept/reference images
- Portfolio → final presentation assets
